% PB performance measure begin
%	pb; 
%
%	PB starts performance measure by storing current CLOCK (t0_clock),
%	and CPUTIME (t0_cputime).
%	See also: PD, TIME_EST, ALARMSIG

% Auther: Powen Ru (powen@isr.umd.edu), NSL, UMD
% v1.00: 01-Jun-97

t0_clock = clock;
t0_cputime = cputime;
%n0_flops = flops;
